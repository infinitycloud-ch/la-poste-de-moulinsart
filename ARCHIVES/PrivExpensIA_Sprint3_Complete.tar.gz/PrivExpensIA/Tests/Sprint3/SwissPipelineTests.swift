import XCTest
import UIKit
@testable import PrivExpensIA

// MARK: - Swiss Pipeline Tests (Sprint 3)
// Validates Swiss fallback patterns and unified pipeline behavior
// Tests Migros, Coop, and restaurant receipts with CHF amounts

class SwissPipelineTests: XCTestCase {

    var unifiedPipeline: UnifiedPipelineManager!
    var logger: PipelineLogger!

    override func setUp() {
        super.setUp()
        unifiedPipeline = UnifiedPipelineManager.shared
        logger = PipelineLogger.shared
    }

    // MARK: - Test Swiss Receipt Samples
    private var migrosReceipt: String {
        return """
        MIGROS
        Bahnhofstrasse 12
        8001 Zürich

        Artikel                 Preis
        Brot Vollkorn          CHF 3.20
        Milch 1L               CHF 1.95
        Äpfel Gala 1kg         CHF 4.50

        Zwischentotal          CHF 9.65
        MwSt 2.5%              CHF 0.24
        TOTAL                  CHF 9.89

        Montant dû             CHF 9.89
        Cumulus Karte: ****1234
        """
    }

    private var coopReceipt: String {
        return """
        COOP
        Supermarkt
        Helvetiaplatz 3, 3005 Bern

        1x Rüebli Bio          CHF 2.30
        2x Pasta Barilla       CHF 5.80
        1x Käse Gruyère        CHF 8.90

        Subtotal               CHF 17.00
        MwSt 7.7%              CHF 1.31
        Total-EFT              CHF 18.31

        Supercard: 1234567890
        """
    }

    private var restaurantReceipt: String {
        return """
        Restaurant Opera Italiana
        Via del Corso 15
        6900 Lugano

        1x Pizza Margherita    CHF 18.00
        1x Insalata Mista      CHF 12.00
        2x Birra Moretti       CHF 14.00
        1x Tiramisu            CHF 8.00

        Subtotale              CHF 52.00
        IVA 7.7%               CHF 4.00
        TOTALE                 CHF 56.00

        Importo da pagare      CHF 56.00
        Grazie per la visita!
        """
    }

    // MARK: - Test Swiss Deterministic Patterns
    func testMigrosReceipt() {
        let expectation = XCTestExpectation(description: "Migros receipt extraction")

        // Create test image from text (simulated)
        let testImage = createTestImage(from: migrosReceipt)

        unifiedPipeline.extractExpense(from: testImage, preferredMode: .parser) { result in
            switch result {
            case .success(let extraction):
                // Verify Swiss fallback was used
                XCTAssertEqual(extraction.extractedData.currency, "CHF", "Should detect CHF currency")
                XCTAssertEqual(extraction.extractedData.totalAmount, 9.89, accuracy: 0.01, "Should extract correct Migros total")
                XCTAssertTrue(extraction.extractedData.merchant.lowercased().contains("migros"), "Should identify Migros as merchant")
                XCTAssertGreaterThan(extraction.confidence, 0.7, "Should have high confidence for Swiss patterns")

                print("✅ Migros Test: CHF \(extraction.extractedData.totalAmount) - Confidence: \(extraction.confidence)")

            case .failure(let error):
                XCTFail("Migros extraction failed: \(error)")
            }

            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 10.0)
    }

    func testCoopReceipt() {
        let expectation = XCTestExpectation(description: "Coop receipt extraction")

        let testImage = createTestImage(from: coopReceipt)

        unifiedPipeline.extractExpense(from: testImage, preferredMode: .parser) { result in
            switch result {
            case .success(let extraction):
                XCTAssertEqual(extraction.extractedData.currency, "CHF", "Should detect CHF currency")
                XCTAssertEqual(extraction.extractedData.totalAmount, 18.31, accuracy: 0.01, "Should extract correct Coop total")
                XCTAssertTrue(extraction.extractedData.merchant.lowercased().contains("coop"), "Should identify Coop as merchant")
                XCTAssertGreaterThan(extraction.confidence, 0.7, "Should have high confidence for Swiss patterns")

                print("✅ Coop Test: CHF \(extraction.extractedData.totalAmount) - Confidence: \(extraction.confidence)")

            case .failure(let error):
                XCTFail("Coop extraction failed: \(error)")
            }

            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 10.0)
    }

    func testRestaurantReceipt() {
        let expectation = XCTestExpectation(description: "Restaurant receipt extraction")

        let testImage = createTestImage(from: restaurantReceipt)

        unifiedPipeline.extractExpense(from: testImage, preferredMode: .parser) { result in
            switch result {
            case .success(let extraction):
                XCTAssertEqual(extraction.extractedData.currency, "CHF", "Should detect CHF currency")
                XCTAssertEqual(extraction.extractedData.totalAmount, 56.00, accuracy: 0.01, "Should extract correct restaurant total")
                XCTAssertTrue(extraction.extractedData.merchant.lowercased().contains("opera"), "Should identify restaurant as merchant")
                XCTAssertGreaterThan(extraction.confidence, 0.6, "Should have reasonable confidence")

                print("✅ Restaurant Test: CHF \(extraction.extractedData.totalAmount) - Confidence: \(extraction.confidence)")

            case .failure(let error):
                XCTFail("Restaurant extraction failed: \(error)")
            }

            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 10.0)
    }

    // MARK: - Test Pipeline Mode Selection
    func testSwissReceiptAutoMode() {
        let expectation = XCTestExpectation(description: "Auto mode should select parser for Swiss")

        let testImage = createTestImage(from: migrosReceipt)

        unifiedPipeline.extractExpense(from: testImage, preferredMode: .auto) { result in
            switch result {
            case .success(let extraction):
                // Auto mode should select parser for Swiss receipts
                XCTAssertEqual(extraction.pipelineUsed, .parser, "Auto mode should select parser for Swiss receipts")
                XCTAssertEqual(extraction.extractedData.totalAmount, 9.89, accuracy: 0.01, "Should still extract correct amount")

                print("✅ Auto Mode Test: Selected \(extraction.pipelineUsed) pipeline")

            case .failure(let error):
                XCTFail("Auto mode test failed: \(error)")
            }

            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 10.0)
    }

    // MARK: - Test Swiss Fallback Edge Cases
    func testSwissReceiptWithoutClearTotal() {
        let complexReceipt = """
        MIGROS
        Article divers
        CHF 2.50
        CHF 1.80
        CHF 5.30
        Réduction CHF -0.60
        ----------------
        Total CHF 9.00
        Merci de votre achat
        """

        let expectation = XCTestExpectation(description: "Complex Swiss receipt")
        let testImage = createTestImage(from: complexReceipt)

        unifiedPipeline.extractExpense(from: testImage, preferredMode: .parser) { result in
            switch result {
            case .success(let extraction):
                XCTAssertEqual(extraction.extractedData.currency, "CHF", "Should detect CHF")
                XCTAssertGreaterThan(extraction.extractedData.totalAmount, 0, "Should never return 0.00 for Swiss receipts")
                XCTAssertEqual(extraction.extractedData.totalAmount, 9.00, accuracy: 0.01, "Should find the total amount")

                print("✅ Complex Swiss Test: CHF \(extraction.extractedData.totalAmount)")

            case .failure(let error):
                XCTFail("Complex Swiss receipt failed: \(error)")
            }

            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 10.0)
    }

    // MARK: - Test Confidence Thresholds
    func testConfidenceThresholds() {
        let expectation = XCTestExpectation(description: "Confidence threshold test")

        let testImage = createTestImage(from: migrosReceipt)

        unifiedPipeline.extractExpense(from: testImage, preferredMode: .parser) { result in
            switch result {
            case .success(let extraction):
                // Swiss receipts should have high confidence due to deterministic patterns
                XCTAssertGreaterThan(extraction.confidence, 0.5, "Should meet minimum confidence threshold")
                XCTAssertFalse(extraction.shouldUseFallback, "Should not require additional fallback")
                XCTAssertTrue(extraction.isHighConfidence || extraction.confidence > 0.6, "Swiss patterns should provide decent confidence")

                print("✅ Confidence Test: \(extraction.confidence) - High: \(extraction.isHighConfidence)")

            case .failure(let error):
                XCTFail("Confidence test failed: \(error)")
            }

            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 10.0)
    }

    // MARK: - Test Correlation System
    func testCorrelationGeneration() {
        let expectation = XCTestExpectation(description: "Correlation system test")

        let testImage = createTestImage(from: coopReceipt)

        unifiedPipeline.extractExpense(from: testImage, preferredMode: .parser) { result in
            switch result {
            case .success(let extraction):
                // Check that correlation ID is generated
                XCTAssertFalse(extraction.correlationId.isEmpty, "Should generate correlation ID")
                XCTAssertNotNil(extraction.screenshot, "Should include screenshot")
                XCTAssertFalse(extraction.logs.isEmpty, "Should include processing logs")

                print("✅ Correlation Test: ID \(extraction.correlationId.prefix(8)) - \(extraction.logs.count) log entries")

                // Verify files are created
                let reportsDir = "/Users/studio_m3/moulinsart/PrivExpensIA/Reports/Sprint3_Audit"
                let screenshotPath = "\(reportsDir)/screenshot_\(extraction.correlationId).png"
                let jsonPath = "\(reportsDir)/extraction_\(extraction.correlationId).json"

                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    XCTAssertTrue(FileManager.default.fileExists(atPath: screenshotPath), "Screenshot should be saved")
                    XCTAssertTrue(FileManager.default.fileExists(atPath: jsonPath), "JSON data should be saved")
                    expectation.fulfill()
                }

            case .failure(let error):
                XCTFail("Correlation test failed: \(error)")
                expectation.fulfill()
            }
        }

        wait(for: [expectation], timeout: 15.0)
    }

    // MARK: - Performance Tests
    func testPerformanceBenchmark() {
        let expectation = XCTestExpectation(description: "Performance benchmark")

        let testImage = createTestImage(from: migrosReceipt)
        let startTime = Date()

        unifiedPipeline.extractExpense(from: testImage, preferredMode: .parser) { result in
            let processingTime = Date().timeIntervalSince(startTime)

            switch result {
            case .success(let extraction):
                XCTAssertLessThan(processingTime, 5.0, "Should complete within 5 seconds")
                XCTAssertLessThan(extraction.processingTime, 3.0, "Internal processing should be under 3 seconds")

                print("✅ Performance Test: \(String(format: "%.2f", processingTime))s total, \(String(format: "%.2f", extraction.processingTime))s internal")

            case .failure(let error):
                XCTFail("Performance test failed: \(error)")
            }

            expectation.fulfill()
        }

        wait(for: [expectation], timeout: 10.0)
    }

    // MARK: - Helper Methods
    private func createTestImage(from text: String) -> UIImage {
        // Create a simple image with text for testing
        // In a real app, this would be actual OCR-scanned image
        let size = CGSize(width: 400, height: 600)
        UIGraphicsBeginImageContext(size)

        let rect = CGRect(origin: .zero, size: size)
        UIColor.white.setFill()
        UIRectFill(rect)

        let textRect = CGRect(x: 20, y: 20, width: 360, height: 560)
        let font = UIFont.systemFont(ofSize: 12)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: UIColor.black
        ]

        text.draw(in: textRect, withAttributes: attributes)

        let image = UIGraphicsGetImageFromCurrentImageContext() ?? UIImage()
        UIGraphicsEndImageContext()

        return image
    }

    // MARK: - Test Cleanup
    override func tearDown() {
        // Clean up test files if needed
        super.tearDown()
    }
}

// MARK: - Integration Test Suite
class SwissIntegrationTests: XCTestCase {

    func testFullPipelineIntegration() {
        let expectation = XCTestExpectation(description: "Full pipeline integration")

        // Test multiple receipts in sequence
        let receipts = [
            ("Migros", createMigrosReceiptText()),
            ("Coop", createCoopReceiptText()),
            ("Restaurant", createRestaurantReceiptText())
        ]

        var completedTests = 0

        for (name, receiptText) in receipts {
            let testImage = createTestImageFromText(receiptText)

            UnifiedPipelineManager.shared.extractExpense(from: testImage, preferredMode: .auto) { result in
                switch result {
                case .success(let extraction):
                    print("✅ Integration Test [\(name)]: CHF \(extraction.extractedData.totalAmount) - Pipeline: \(extraction.pipelineUsed)")
                    XCTAssertGreaterThan(extraction.extractedData.totalAmount, 0, "\(name) should extract non-zero amount")

                case .failure(let error):
                    XCTFail("\(name) integration test failed: \(error)")
                }

                completedTests += 1
                if completedTests == receipts.count {
                    expectation.fulfill()
                }
            }
        }

        wait(for: [expectation], timeout: 30.0)
    }

    private func createMigrosReceiptText() -> String {
        return """
        MIGROS
        Limmatquai 15, 8001 Zürich

        Bananen             CHF 2.40
        Brot Ruchmehl       CHF 3.20
        Käse Appenzeller    CHF 7.80

        Total               CHF 13.40
        """
    }

    private func createCoopReceiptText() -> String {
        return """
        COOP City
        Rennweg 46, 8001 Zürich

        Bio Äpfel           CHF 4.50
        Vollmilch 1L        CHF 1.55

        TOTAL EFT           CHF 6.05
        """
    }

    private func createRestaurantReceiptText() -> String {
        return """
        Café du Marché
        Place du Marché 8, 1003 Lausanne

        Café                CHF 4.50
        Croissant           CHF 3.50

        À payer             CHF 8.00
        """
    }

    private func createTestImageFromText(_ text: String) -> UIImage {
        let size = CGSize(width: 300, height: 400)
        UIGraphicsBeginImageContext(size)

        UIColor.white.setFill()
        UIRectFill(CGRect(origin: .zero, size: size))

        let attributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.systemFont(ofSize: 10),
            .foregroundColor: UIColor.black
        ]

        text.draw(in: CGRect(x: 10, y: 10, width: 280, height: 380), withAttributes: attributes)

        let image = UIGraphicsGetImageFromCurrentImageContext() ?? UIImage()
        UIGraphicsEndImageContext()

        return image
    }
}