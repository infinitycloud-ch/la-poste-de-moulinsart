import Foundation
import UIKit

// MARK: - Expense Parser
class ExpenseParser {
    static let shared = ExpenseParser()
    
    private let tvaCalculator = TVACalculator.shared
    
    private init() {}
    
    // MARK: - Parse from OCR Result
    func parseFromOCRResult(_ ocrData: ExtractedData) -> ParsedExpense {
        let text = ocrData.text
        return parseExpense(from: text)
    }
    
    // MARK: - Main Parser
    func parseExpense(from text: String) -> ParsedExpense {
        var parsed = ParsedExpense()
        
        // Detect country first for VAT calculation
        parsed.country = tvaCalculator.detectCountryFromText(text)
        
        // Extract merchant
        parsed.merchant = extractMerchant(from: text)
        
        // Extract date
        parsed.date = extractDate(from: text)
        
        // Detect category
        parsed.category = tvaCalculator.detectCategoryFromText(text)
        
        // Extract amounts and currency
        let (amounts, currency) = extractAmounts(from: text)
        parsed.currency = currency
        
        // Find total amount (usually the largest amount)
        if let total = amounts.max() {
            parsed.totalAmount = total
            
            // Calculate VAT
            let vatCalc = tvaCalculator.calculateVAT(
                amount: total,
                country: parsed.country,
                category: parsed.category,
                isInclusive: true
            )
            
            parsed.vatAmount = vatCalc.vatAmount
            parsed.netAmount = vatCalc.netAmount
            parsed.vatRate = vatCalc.vatRate
        }
        
        // Extract items
        parsed.items = extractItems(from: text, amounts: amounts)
        
        // Detect payment method
        parsed.paymentMethod = detectPaymentMethod(from: text)
        
        return parsed
    }
    
    // MARK: - Merchant Extraction
    private func extractMerchant(from text: String) -> String {
        let lines = text.components(separatedBy: .newlines)
        
        // Common merchant patterns (usually in first few lines)
        let merchantPatterns = [
            "migros", "coop", "denner", "lidl", "aldi", "manor",
            "starbucks", "mcdonalds", "burger king",
            "sbb", "cff", "uber",
            "restaurant", "café", "hotel"
        ]
        
        // Check first 3 lines for merchant name
        for i in 0..<min(3, lines.count) {
            let line = lines[i].lowercased()
            for pattern in merchantPatterns {
                if line.contains(pattern) {
                    return lines[i].trimmingCharacters(in: .whitespacesAndNewlines)
                }
            }
        }
        
        // If no pattern matched, use first non-empty line
        if let firstLine = lines.first(where: { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) {
            return firstLine.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        
        return "Unknown Merchant"
    }
    
    // MARK: - Date Extraction
    private func extractDate(from text: String) -> Date {
        let datePatterns = [
            #"(\d{1,2})[./](\d{1,2})[./](\d{2,4})"#,  // DD/MM/YYYY or DD.MM.YYYY
            #"(\d{2,4})-(\d{1,2})-(\d{1,2})"#,         // YYYY-MM-DD
            #"(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+(\d{2,4})"# // DD Month YYYY
        ]
        
        for pattern in datePatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) {
                let matches = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))
                
                if let match = matches.first {
                    let dateString = String(text[Range(match.range, in: text)!])
                    
                    // Try various date formatters
                    let formatters = [
                        "dd/MM/yyyy", "dd.MM.yyyy", "dd-MM-yyyy",
                        "yyyy-MM-dd", "dd MMM yyyy", "dd MMMM yyyy"
                    ]
                    
                    for format in formatters {
                        let formatter = DateFormatter()
                        formatter.dateFormat = format
                        formatter.locale = Locale(identifier: "en_US")
                        
                        if let date = formatter.date(from: dateString) {
                            return date
                        }
                    }
                }
            }
        }
        
        // Default to today if no date found
        return Date()
    }
    
    // MARK: - Enhanced Amount Extraction with Swiss Fallback
    private func extractAmounts(from text: String) -> ([Double], String) {
        var amounts: [Double] = []
        var currency = "CHF" // Default

        // Detect currency
        if text.contains("€") || text.contains("EUR") {
            currency = "EUR"
        } else if text.contains("$") || text.contains("USD") {
            currency = "USD"
        } else if text.contains("CHF") || text.contains("Fr.") {
            currency = "CHF"
        } else if text.contains("¥") || text.contains("JPY") {
            currency = "JPY"
        } else if text.contains("£") || text.contains("GBP") {
            currency = "GBP"
        }

        // 🇨🇭 SPRINT 3: Swiss Deterministic Fallback
        // Priority patterns for Swiss receipts - NEVER return 0.00 if these patterns exist
        if currency == "CHF" {
            if let swissAmount = extractSwissDeterministicAmount(from: text) {
                print("🇨🇭 [Swiss Fallback] Found deterministic amount: CHF \(swissAmount)")
                amounts.append(swissAmount)
                return (amounts, currency)
            }
        }

        // Standard amount patterns (enhanced)
        let amountPatterns = [
            #"(\d{1,4})[.,](\d{2})"#,           // 123.45 or 123,45
            #"(\d{1,4})\s*[.,]\s*(\d{2})"#,     // 123 . 45 (with spaces)
            #"[€$£¥]\s*(\d{1,4})[.,](\d{2})"#,  // €123.45
            #"(\d{1,4})[.,](\d{2})\s*[€$£¥]"#,  // 123.45€
            #"CHF\s*(\d{1,4})[.,](\d{2})"#,     // CHF 123.45
            #"Fr[.]?\s*(\d{1,4})[.,](\d{2})"#   // Fr. 123.45
        ]
        
        for pattern in amountPatterns {
            if let regex = try? NSRegularExpression(pattern: pattern, options: []) {
                let matches = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))
                
                for match in matches {
                    let amountString = String(text[Range(match.range, in: text)!])
                    
                    // Extract numeric value
                    let cleanedString = amountString
                        .replacingOccurrences(of: "[^0-9.,]", with: "", options: .regularExpression)
                        .replacingOccurrences(of: ",", with: ".")
                    
                    if let amount = Double(cleanedString), amount > 0 {
                        amounts.append(amount)
                    }
                }
            }
        }
        
        // Remove duplicates and sort
        amounts = Array(Set(amounts)).sorted()
        
        return (amounts, currency)
    }
    
    // MARK: - Item Extraction
    private func extractItems(from text: String, amounts: [Double]) -> [String] {
        var items: [String] = []
        let lines = text.components(separatedBy: .newlines)
        
        // Look for lines with amounts (likely to be items)
        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            
            // Skip empty lines and headers
            if trimmed.isEmpty || trimmed.count < 3 {
                continue
            }
            
            // Check if line contains an amount
            for amount in amounts {
                let amountStr = String(format: "%.2f", amount)
                if line.contains(amountStr) || line.contains(amountStr.replacingOccurrences(of: ".", with: ",")) {
                    // Extract item name (text before the amount)
                    if let range = line.range(of: amountStr) {
                        let itemName = String(line[..<range.lowerBound])
                            .trimmingCharacters(in: .whitespacesAndNewlines)
                            .replacingOccurrences(of: #"^\d+\s*"#, with: "", options: .regularExpression) // Remove leading quantity
                        
                        if !itemName.isEmpty && itemName.count > 2 {
                            items.append(itemName)
                        }
                    }
                    break
                }
            }
        }
        
        // If no items found, try to extract product-like words
        if items.isEmpty {
            let productKeywords = ["pizza", "café", "sandwich", "burger", "salade", "pasta",
                                  "billet", "ticket", "chambre", "room", "service", "tartare", "saumon"]
            
            for line in lines {
                let lowercased = line.lowercased()
                for keyword in productKeywords {
                    if lowercased.contains(keyword) {
                        items.append(line.trimmingCharacters(in: .whitespacesAndNewlines))
                        break
                    }
                }
                if items.count >= 3 { break } // Limit to 3 items
            }
        }
        
        return items
    }
    
    // MARK: - Payment Method Detection
    private func detectPaymentMethod(from text: String) -> String {
        let lowercased = text.lowercased()
        
        if lowercased.contains("visa") {
            return "Visa"
        } else if lowercased.contains("mastercard") || lowercased.contains("master card") {
            return "Mastercard"
        } else if lowercased.contains("amex") || lowercased.contains("american express") {
            return "Amex"
        } else if lowercased.contains("cash") || lowercased.contains("espèces") || lowercased.contains("bar") {
            return "Cash"
        } else if lowercased.contains("twint") {
            return "Twint"
        } else if lowercased.contains("paypal") {
            return "PayPal"
        } else if lowercased.contains("apple pay") {
            return "Apple Pay"
        } else if lowercased.contains("google pay") {
            return "Google Pay"
        } else if lowercased.contains("debit") {
            return "Debit Card"
        } else if lowercased.contains("credit") {
            return "Credit Card"
        }
        
        return "Card"
    }

    // MARK: - 🇨🇭 Swiss Deterministic Fallback (Sprint 3)
    // NEVER returns 0.00 if Swiss patterns are found
    private func extractSwissDeterministicAmount(from text: String) -> Double? {
        print("🇨🇭 [Swiss Fallback] Analyzing text for Swiss patterns...")

        // Priority Swiss patterns - most reliable first
        let swissPatterns = [
            // Migros/Coop specific patterns
            #"(?i)(?:Montant dû|Total à payer|TOTAL EFT|Total-EFT)\s*:?\s*CHF\s*([0-9]+[.,][0-9]{2})"#,
            #"(?i)(?:Total|TOTAL)\s*CHF\s*([0-9]+[.,][0-9]{2})"#,
            #"(?i)CHF\s*([0-9]+[.,][0-9]{2})\s*(?:Total|TOTAL|Montant|MONTANT)"#,

            // Generic Swiss patterns
            #"(?i)(?:Zu zahlen|À payer|Da pagare)\s*:?\s*CHF\s*([0-9]+[.,][0-9]{2})"#,
            #"(?i)(?:Betrag|Montant|Importo)\s*:?\s*CHF\s*([0-9]+[.,][0-9]{2})"#,

            // Cumulus/Loyalty card patterns
            #"(?i)(?:Cumulus|Supercard)\s*.*CHF\s*([0-9]+[.,][0-9]{2})"#,

            // Simple CHF amount at end of line (often total)
            #"CHF\s*([0-9]+[.,][0-9]{2})\s*$"#
        ]

        for (index, pattern) in swissPatterns.enumerated() {
            do {
                let regex = try NSRegularExpression(pattern: pattern, options: [])
                let matches = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))

                for match in matches {
                    if let range = Range(match.range(at: 1), in: text) {
                        let amountString = String(text[range])
                            .replacingOccurrences(of: ",", with: ".")

                        if let amount = Double(amountString), amount > 0 {
                            print("🇨🇭 [Swiss Fallback] Pattern \(index + 1) matched: CHF \(amount)")
                            return amount
                        }
                    }
                }
            } catch {
                print("🇨🇭 [Swiss Fallback] Regex error for pattern \(index + 1): \(error)")
            }
        }

        // Advanced Swiss receipt heuristics
        if let heuristicAmount = extractSwissHeuristicAmount(from: text) {
            return heuristicAmount
        }

        print("🇨🇭 [Swiss Fallback] No Swiss patterns found")
        return nil
    }

    // MARK: - Swiss Heuristic Amount Extraction
    private func extractSwissHeuristicAmount(from text: String) -> Double? {
        print("🇨🇭 [Swiss Heuristic] Applying Swiss receipt heuristics...")

        let lines = text.components(separatedBy: .newlines)
        var candidates: [(amount: Double, confidence: Int)] = []

        for (lineIndex, line) in lines.enumerated() {
            let trimmedLine = line.trimmingCharacters(in: .whitespacesAndNewlines)

            // Look for CHF amounts in each line
            let chfPattern = #"CHF\s*([0-9]+[.,][0-9]{2})"#
            if let regex = try? NSRegularExpression(pattern: chfPattern),
               let match = regex.firstMatch(in: trimmedLine, range: NSRange(trimmedLine.startIndex..., in: trimmedLine)),
               let range = Range(match.range(at: 1), in: trimmedLine) {

                let amountString = String(trimmedLine[range]).replacingOccurrences(of: ",", with: ".")
                if let amount = Double(amountString), amount > 0 {

                    var confidence = 1
                    let lowerLine = trimmedLine.lowercased()

                    // Increase confidence for total indicators
                    if lowerLine.contains("total") || lowerLine.contains("montant") {
                        confidence += 3
                    }

                    // Increase confidence for payment indicators
                    if lowerLine.contains("dû") || lowerLine.contains("payer") || lowerLine.contains("zahlen") {
                        confidence += 2
                    }

                    // Increase confidence if near end of receipt
                    if lineIndex > lines.count - 10 {
                        confidence += 1
                    }

                    // Decrease confidence for change/returned money
                    if lowerLine.contains("change") || lowerLine.contains("rendu") || lowerLine.contains("rückgeld") {
                        confidence -= 2
                    }

                    candidates.append((amount: amount, confidence: confidence))
                    print("🇨🇭 [Swiss Heuristic] Candidate: CHF \(amount) (confidence: \(confidence))")
                }
            }
        }

        // Return highest confidence amount
        if let bestCandidate = candidates.max(by: { $0.confidence < $1.confidence }) {
            print("🇨🇭 [Swiss Heuristic] Selected: CHF \(bestCandidate.amount) (confidence: \(bestCandidate.confidence))")
            return bestCandidate.amount
        }

        print("🇨🇭 [Swiss Heuristic] No reliable candidates found")
        return nil
    }

    // MARK: - Create ExpenseData
    func createExpenseData(from parsed: ParsedExpense) -> ExpenseData {
        return ExpenseData(
            id: UUID(),
            date: parsed.date,
            merchant: parsed.merchant,
            amount: parsed.totalAmount,
            tax: parsed.vatAmount,
            category: parsed.category,
            items: parsed.items,
            paymentMethod: parsed.paymentMethod
        )
    }
}

// MARK: - Parsed Expense Model
struct ParsedExpense {
    var merchant: String = "Unknown"
    var totalAmount: Double = 0
    var netAmount: Double = 0
    var vatAmount: Double = 0
    var vatRate: Double = 0
    var currency: String = "CHF"
    var date: Date = Date()
    var category: String = "other"
    var items: [String] = []
    var paymentMethod: String = "Card"
    var country: String = "CH"
    
    var formattedTotal: String {
        let symbol = getCurrencySymbol(currency)
        return "\(symbol)\(String(format: "%.2f", totalAmount))"
    }
    
    var formattedVAT: String {
        return String(format: "%.2f", vatAmount)
    }
    
    var formattedVATRate: String {
        return String(format: "%.1f%%", vatRate)
    }
    
    private func getCurrencySymbol(_ currency: String) -> String {
        switch currency {
        case "EUR": return "€"
        case "USD": return "$"
        case "GBP": return "£"
        case "CHF": return "CHF "
        case "JPY": return "¥"
        default: return currency + " "
        }
    }
}