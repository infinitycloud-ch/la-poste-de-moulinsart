import SwiftUI
import VisionKit
import PhotosUI

// MARK: - Extracted Expense Data for UI
struct ExtractedExpenseData {
    var merchant: String
    var totalAmount: Double
    var taxAmount: Double
    var date: Date
    var category: String
    var items: String?
    var paymentMethod: String?
    var confidence: Double
}

// MARK: - Scanner View with Glass UI
struct ScannerGlassView: View {
    @Binding var isScanning: Bool
    @State private var selectedImage: UIImage?
    @State private var showingImagePicker = false
    @State private var showingCamera = false
    @State private var showingDocumentPicker = false
    @State private var showingResult = false
    @State private var extractedData: ExtractedExpenseData?
    @State private var currentImage: UIImage?
    @State private var isProcessing = false
    @State private var scanProgress: Double = 0
    @State private var useAIMode = Constants.AIMode.isEnabled  // Toggle mode IA depuis Settings
    
    var body: some View {
        ZStack {
            // Background already in MainTabView
            
            if isProcessing {
                processingView
            } else if showingResult, let data = extractedData {
                ResultGlassView(data: data, onSave: saveExpense, onRetry: retry)
            } else {
                scanOptionsView
            }
        }
        .sheet(isPresented: $showingCamera) {
            DocumentScannerView { image in
                processScannedImage(image)
            }
        }
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(image: $selectedImage)
                .onDisappear {
                    if let image = selectedImage {
                        processScannedImage(image)
                    }
                }
        }
        .sheet(isPresented: $showingDocumentPicker) {
            DocumentPicker { url in
                if let image = loadImage(from: url) {
                    processScannedImage(image)
                }
            }
        }
        .onAppear {
            // Synchroniser avec les Settings
            useAIMode = Constants.AIMode.isEnabled
        }
    }
    
    // MARK: - Scan Options View
    private var scanOptionsView: some View {
        VStack(spacing: LiquidGlassTheme.Layout.spacing24) {
            // Header
            VStack(spacing: LiquidGlassTheme.Layout.spacing8) {
                Image(systemName: "doc.text.viewfinder")
                    .font(.system(size: 60))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [
                                LiquidGlassTheme.Colors.accent,
                                LiquidGlassTheme.Colors.primary
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                
                Text(LocalizationManager.shared.localized("scan_receipt"))
                    .font(LiquidGlassTheme.Typography.displaySmall)
                    .foregroundColor(LiquidGlassTheme.Colors.textPrimary)
                
                Text(LocalizationManager.shared.localized("scan_receipt_subtitle"))
                    .font(LiquidGlassTheme.Typography.body)
                    .foregroundColor(LiquidGlassTheme.Colors.textSecondary)
                    .multilineTextAlignment(.center)
            }
            .padding(.top, LiquidGlassTheme.Layout.spacing40)
            
            // Mode Selector
            GlassCard {
                VStack(spacing: LiquidGlassTheme.Layout.spacing12) {
                    HStack {
                        Image(systemName: "brain.head.profile")
                            .foregroundColor(useAIMode ? LiquidGlassTheme.Colors.accent : LiquidGlassTheme.Colors.textSecondary)

                        Text(LocalizationManager.shared.localized("settings.ai_mode"))
                            .font(LiquidGlassTheme.Typography.headline)
                            .foregroundColor(LiquidGlassTheme.Colors.textPrimary)

                        Spacer()

                        Toggle("", isOn: $useAIMode)
                            .toggleStyle(SwitchToggleStyle(tint: LiquidGlassTheme.Colors.accent))
                            .onChange(of: useAIMode) { newValue in
                                Constants.AIMode.isEnabled = newValue
                            }
                    }

                    Text(useAIMode ? LocalizationManager.shared.localized("ai_mode_qwen_description") : LocalizationManager.shared.localized("ai_mode_fast_description"))
                        .font(LiquidGlassTheme.Typography.caption1)
                        .foregroundColor(LiquidGlassTheme.Colors.textSecondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .padding(.horizontal, LiquidGlassTheme.Layout.spacing20)

            Spacer()

            // Scan Options
            VStack(spacing: LiquidGlassTheme.Layout.spacing16) {
                ScanOptionCard(
                    icon: "camera.fill",
                    title: LocalizationManager.shared.localized("scan_option_camera"),
                    description: LocalizationManager.shared.localized("scan_option_camera_description"),
                    color: LiquidGlassTheme.Colors.accent
                ) {
                    showingCamera = true
                }
                
                ScanOptionCard(
                    icon: "photo.fill",
                    title: LocalizationManager.shared.localized("scan_option_library"),
                    description: LocalizationManager.shared.localized("scan_option_library_description"),
                    color: LiquidGlassTheme.Colors.primary
                ) {
                    showingImagePicker = true
                }
                
                ScanOptionCard(
                    icon: "doc.fill",
                    title: LocalizationManager.shared.localized("scan_option_files"),
                    description: LocalizationManager.shared.localized("scan_option_files_description"),
                    color: Color.orange
                ) {
                    showingDocumentPicker = true
                }
            }
            .padding(.horizontal, LiquidGlassTheme.Layout.spacing20)
            
            Spacer()
            
            // Tips
            GlassCard {
                HStack {
                    Image(systemName: "lightbulb.fill")
                        .foregroundColor(Color.yellow)
                    
                    Text(LocalizationManager.shared.localized("scan_tip"))
                        .font(LiquidGlassTheme.Typography.caption1)
                        .foregroundColor(LiquidGlassTheme.Colors.textSecondary)
                }
            }
            .padding(.horizontal, LiquidGlassTheme.Layout.spacing20)
            .padding(.bottom, LiquidGlassTheme.Layout.spacing40)
        }
    }
    
    // MARK: - Processing View
    private var processingView: some View {
        VStack(spacing: LiquidGlassTheme.Layout.spacing32) {
            Spacer()
            
            // Animated Scanner Icon
            ZStack {
                Circle()
                    .fill(LiquidGlassTheme.Colors.glassLight)
                    .frame(width: 120, height: 120)
                
                Image(systemName: "doc.text.magnifyingglass")
                    .font(.system(size: 50))
                    .foregroundColor(LiquidGlassTheme.Colors.accent)
                    .rotationEffect(.degrees(scanProgress * 360))
                    .animation(
                        Animation.linear(duration: 2)
                            .repeatForever(autoreverses: false),
                        value: scanProgress
                    )
            }
            
            VStack(spacing: LiquidGlassTheme.Layout.spacing12) {
                Text(LocalizationManager.shared.localized("processing_receipt"))
                    .font(LiquidGlassTheme.Typography.title1)
                    .foregroundColor(LiquidGlassTheme.Colors.textPrimary)
                
                Text(LocalizationManager.shared.localized("processing_receipt_ai"))
                    .font(LiquidGlassTheme.Typography.body)
                    .foregroundColor(LiquidGlassTheme.Colors.textSecondary)
            }
            
            // Progress Bar
            ProgressView(value: scanProgress)
                .progressViewStyle(GlassProgressViewStyle())
                .frame(width: 200)
            
            Spacer()
        }
        .onAppear {
            withAnimation {
                scanProgress = 1.0
            }
        }
    }
    
    // MARK: - Actions
    private func processScannedImage(_ image: UIImage) {
        currentImage = image  // Stocker l'image pour la sauvegarde
        isProcessing = true
        scanProgress = 0

        // Choisir le mode selon Constants.AIMode.isEnabled (autorité)
        let aiModeEnabled = Constants.AIMode.isEnabled
        print("[AI_MODE] Current setting: \(aiModeEnabled)")

        if aiModeEnabled {
            print("[AI_MODE] Using AI structured extraction")
            processImageAIMode(image)
        } else {
            print("[AI_MODE] Using simple OCR mode")
            processImageSimpleMode(image)
        }
    }

    // Mode IA complet avec Pipeline Unifié Sprint 3
    private func processImageAIMode(_ image: UIImage) {
        let unifiedPipeline = UnifiedPipelineManager.shared

        // Start animated progress pour IA (plus long)
        withAnimation(.linear(duration: 2.0)) {
            scanProgress = 0.3
        }

        print("[UNIFIED_PIPELINE] Starting extraction with auto mode")
        unifiedPipeline.extractExpense(from: image, preferredMode: .auto) { result in
            DispatchQueue.main.async {
                print("[UNIFIED_PIPELINE] Extraction completed")

                switch result {
                case .success(let unifiedResult):
                    let extractedData = unifiedResult.extractedData
                    print("[UNIFIED_PIPELINE] Success: \(extractedData.merchant) - \(extractedData.formattedAmount) (pipeline: \(unifiedResult.pipelineUsed.rawValue))")

                    // Convert unified data to UI format
                    withAnimation(AnimationManager.Glass.fadeIn) {
                        self.extractedData = ExtractedExpenseData(
                            merchant: extractedData.merchant,
                            totalAmount: extractedData.totalAmount,
                            taxAmount: extractedData.taxAmount,
                            date: extractedData.date,
                            category: extractedData.category,
                            items: nil, // Items handling simplified for now
                            paymentMethod: nil,
                            confidence: extractedData.confidence
                        )
                        self.isProcessing = false
                        self.showingResult = true
                        self.scanProgress = 1.0

                        // Success haptic
                        LiquidGlassTheme.Haptics.success()
                    }

                case .failure(let error):
                    print("[UNIFIED_PIPELINE] Failed: \(error)")
                    // Fallback to regex extraction if unified pipeline fails
                    self.performFallbackExtraction(from: image)
                }
            }
        }
    }

    // Mode simple OCR seul (Vision Framework)
    private func processImageSimpleMode(_ image: UIImage) {
        let ocrService = OCRService.shared

        // Start animated progress pour mode simple (plus rapide)
        withAnimation(.linear(duration: 0.5)) {
            scanProgress = 0.3
        }

        ocrService.processImageSimple(image) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let extractedText):
                    print("[SCAN][simpleOCR] Text extracted, using parser fallback")

                    // Use ExpenseParser pour extraire les données du texte OCR
                    let parser = ExpenseParser.shared
                    let parsed = parser.parseExpense(from: extractedText)

                    withAnimation(AnimationManager.Glass.fadeIn) {
                        self.extractedData = ExtractedExpenseData(
                            merchant: parsed.merchant,
                            totalAmount: parsed.totalAmount,
                            taxAmount: parsed.vatAmount,
                            date: parsed.date,
                            category: parsed.category,
                            items: nil,
                            paymentMethod: parsed.paymentMethod,
                            confidence: 0.7 // Confiance modérée pour mode simple
                        )
                        self.isProcessing = false
                        self.showingResult = true
                        self.scanProgress = 1.0

                        // Light haptic for simple mode
                        LiquidGlassTheme.Haptics.light()
                    }

                case .failure(let error):
                    print("[SCAN][simpleOCR] OCR failed: \(error)")
                    // Fallback complet en cas d'échec OCR
                    self.extractedData = ExtractedExpenseData(
                        merchant: "OCR Failed",
                        totalAmount: 0,
                        taxAmount: 0,
                        date: Date(),
                        category: "Other",
                        items: nil,
                        paymentMethod: nil,
                        confidence: 0
                    )
                    self.isProcessing = false
                    self.showingResult = true

                    // Error haptic
                    LiquidGlassTheme.Haptics.error()
                }
            }
        }
    }

// Fallback extraction using ExpenseParser
    private func performFallbackExtraction(from image: UIImage) {
        // Use OCR directly with fallback parser
        let ocrService = OCRService.shared

        ocrService.processImage(image) { result in

            DispatchQueue.main.async {
                switch result {
                case .success(let ocrData):
                    // Use ExpenseParser as backup
                    let parser = ExpenseParser.shared
                    let parsed = parser.parseExpense(from: ocrData.text)

                    withAnimation(AnimationManager.Glass.fadeIn) {
                        self.extractedData = ExtractedExpenseData(
                            merchant: parsed.merchant,
                            totalAmount: parsed.totalAmount,
                            taxAmount: parsed.vatAmount,
                            date: parsed.date,
                            category: parsed.category,
                            items: nil,
                            paymentMethod: parsed.paymentMethod,
                            confidence: 0.6 // Lower confidence for fallback
                        )
                        self.isProcessing = false
                        self.showingResult = true

                        // Light haptic for fallback
                        LiquidGlassTheme.Haptics.light()
                    }

                case .failure:
                    // Complete failure - show error
                    self.extractedData = ExtractedExpenseData(
                        merchant: "Extraction Failed",
                        totalAmount: 0,
                        taxAmount: 0,
                        date: Date(),
                        category: "Other",
                        items: nil,
                        paymentMethod: nil,
                        confidence: 0
                    )
                    self.isProcessing = false
                    self.showingResult = true

                    // Error haptic
                    LiquidGlassTheme.Haptics.error()
                }
            }
        }
    }
    
    private func saveExpense() {
        // ACTIVÉ: Sauvegarde en Core Data
        guard let data = extractedData else { return }

        let coreDataManager = CoreDataManager.shared

        // Create expense object for Core Data
        let expense = Expense(context: coreDataManager.persistentContainer.viewContext)
        expense.id = UUID()
        expense.merchant = data.merchant
        expense.amount = data.totalAmount
        expense.taxAmount = data.taxAmount
        expense.date = data.date
        expense.category = data.category
        expense.notes = data.items
        expense.paymentMethod = data.paymentMethod
        expense.confidence = data.confidence
        expense.createdAt = Date()
        expense.currency = "EUR" // Default currency

        // Sauvegarder l'image du reçu
        if let image = currentImage {
            expense.receiptImageData = image.jpegData(compressionQuality: 0.8)
        }

        // Save to Core Data
        do {
            try coreDataManager.persistentContainer.viewContext.save()

            // Success feedback
            LiquidGlassTheme.Haptics.success()

            // Log success
            print("✅ Expense saved: \(data.merchant) - \(data.totalAmount)€")

            // Reset UI
            isScanning = false
            showingResult = false
            extractedData = nil

        } catch {
            // Error handling
            print("❌ Failed to save expense: \(error)")
            LiquidGlassTheme.Haptics.error()

            // Still close the scanner but show error
            isScanning = false
            showingResult = false
            extractedData = nil
        }
    }
    
    private func retry() {
        showingResult = false
        extractedData = nil
    }

    private func loadImage(from url: URL) -> UIImage? {
        guard url.startAccessingSecurityScopedResource() else {
            return nil
        }
        defer { url.stopAccessingSecurityScopedResource() }

        if let data = try? Data(contentsOf: url) {
            if let image = UIImage(data: data) {
                return image
            } else if let pdfImage = convertPDFToImage(data: data) {
                return pdfImage
            }
        }
        return nil
    }

    private func convertPDFToImage(data: Data) -> UIImage? {
        guard let provider = CGDataProvider(data: data as CFData),
              let pdfDoc = CGPDFDocument(provider),
              let pdfPage = pdfDoc.page(at: 1) else {
            return nil
        }

        let pageRect = pdfPage.getBoxRect(.mediaBox)
        let renderer = UIGraphicsImageRenderer(size: pageRect.size)

        let image = renderer.image { ctx in
            UIColor.white.set()
            ctx.fill(pageRect)
            ctx.cgContext.translateBy(x: 0, y: pageRect.size.height)
            ctx.cgContext.scaleBy(x: 1.0, y: -1.0)
            ctx.cgContext.drawPDFPage(pdfPage)
        }

        return image
    }
}

// MARK: - Scan Option Card
struct ScanOptionCard: View {
    let icon: String
    let title: String
    let description: String
    let color: Color
    let action: () -> Void
    
    @State private var isPressed = false
    
    var body: some View {
        Button(action: {
            LiquidGlassTheme.Haptics.light()
            action()
        }) {
            HStack(spacing: LiquidGlassTheme.Layout.spacing16) {
                ZStack {
                    Circle()
                        .fill(color.opacity(0.1))
                        .frame(width: 56, height: 56)
                    
                    Image(systemName: icon)
                        .font(.system(size: 24))
                        .foregroundColor(color)
                }
                
                VStack(alignment: .leading, spacing: LiquidGlassTheme.Layout.spacing4) {
                    Text(title)
                        .font(LiquidGlassTheme.Typography.headline)
                        .foregroundColor(LiquidGlassTheme.Colors.textPrimary)
                    
                    Text(description)
                        .font(LiquidGlassTheme.Typography.caption1)
                        .foregroundColor(LiquidGlassTheme.Colors.textSecondary)
                }
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.system(size: 14))
                    .foregroundColor(LiquidGlassTheme.Colors.textTertiary)
            }
            .padding(LiquidGlassTheme.Layout.spacing16)
            .background(
                GlassBackground(cornerRadius: LiquidGlassTheme.Layout.cornerRadiusMedium)
            )
            .scaleEffect(isPressed ? 0.98 : 1.0)
        }
        .buttonStyle(PlainButtonStyle())
        .onLongPressGesture(minimumDuration: 0, maximumDistance: .infinity,
                          pressing: { pressing in
                            withAnimation(AnimationManager.Gestures.tapFeedback) {
                                isPressed = pressing
                            }
                          },
                          perform: {})
    }
}

// MARK: - Result View
struct ResultGlassView: View {
    let data: ExtractedExpenseData
    let onSave: () -> Void
    let onRetry: () -> Void
    
    @State private var editedData: ExtractedExpenseData
    @State private var isEditing = false
    
    init(data: ExtractedExpenseData, onSave: @escaping () -> Void, onRetry: @escaping () -> Void) {
        self.data = data
        self.onSave = onSave
        self.onRetry = onRetry
        self._editedData = State(initialValue: data)
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: LiquidGlassTheme.Layout.spacing20) {
                // Header
                VStack(spacing: LiquidGlassTheme.Layout.spacing8) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 50))
                        .foregroundColor(LiquidGlassTheme.Colors.success)
                    
                    Text(LocalizationManager.shared.localized("receipt_scanned"))
                        .font(LiquidGlassTheme.Typography.title1)
                        .foregroundColor(LiquidGlassTheme.Colors.textPrimary)
                    
                    HStack {
                        Image(systemName: "sparkles")
                            .foregroundColor(LiquidGlassTheme.Colors.accent)
                        Text("AI Confidence: \(Int(data.confidence * 100))%")
                            .font(LiquidGlassTheme.Typography.caption1)
                            .foregroundColor(LiquidGlassTheme.Colors.textSecondary)
                    }
                }
                .padding(.top, LiquidGlassTheme.Layout.spacing20)
                
                // Extracted Data
                GlassCard {
                    VStack(spacing: LiquidGlassTheme.Layout.spacing16) {
                        DataRow(label: "Merchant", value: editedData.merchant, isEditing: $isEditing)
                        Divider().background(LiquidGlassTheme.Colors.glassLight)
                        
                        DataRow(label: "Amount", value: String(format: "€%.2f", editedData.totalAmount), isEditing: $isEditing)
                        Divider().background(LiquidGlassTheme.Colors.glassLight)
                        
                        DataRow(label: "Tax", value: String(format: "€%.2f", editedData.taxAmount), isEditing: $isEditing)
                        Divider().background(LiquidGlassTheme.Colors.glassLight)
                        
                        DataRow(label: "Category", value: editedData.category, isEditing: $isEditing)
                        Divider().background(LiquidGlassTheme.Colors.glassLight)
                        
                        DataRow(label: "Payment", value: editedData.paymentMethod ?? "Cash", isEditing: $isEditing)
                    }
                }
                
                // Actions
                VStack(spacing: LiquidGlassTheme.Layout.spacing12) {
                    GlassButton(LocalizationManager.shared.localized("save_expense"), icon: "checkmark.circle.fill") {
                        onSave()
                    }
                    
                    HStack(spacing: LiquidGlassTheme.Layout.spacing12) {
                        Button(action: {
                            isEditing.toggle()
                            LiquidGlassTheme.Haptics.light()
                        }) {
                            HStack {
                                Image(systemName: isEditing ? "checkmark" : "pencil")
                                Text(isEditing ? LocalizationManager.shared.localized("button_done") : LocalizationManager.shared.localized("button_edit"))
                            }
                            .font(LiquidGlassTheme.Typography.body)
                            .foregroundColor(LiquidGlassTheme.Colors.accent)
                            .frame(maxWidth: .infinity)
                            .padding(LiquidGlassTheme.Layout.spacing12)
                            .background(
                                GlassBackground(cornerRadius: LiquidGlassTheme.Layout.cornerRadiusMedium)
                                    .opacity(0.5)
                            )
                        }
                        
                        Button(action: onRetry) {
                            HStack {
                                Image(systemName: "arrow.counterclockwise")
                                Text(LocalizationManager.shared.localized("button_retry"))
                            }
                            .font(LiquidGlassTheme.Typography.body)
                            .foregroundColor(LiquidGlassTheme.Colors.textSecondary)
                            .frame(maxWidth: .infinity)
                            .padding(LiquidGlassTheme.Layout.spacing12)
                            .background(
                                GlassBackground(cornerRadius: LiquidGlassTheme.Layout.cornerRadiusMedium)
                                    .opacity(0.5)
                            )
                        }
                    }
                }
                .padding(.horizontal, LiquidGlassTheme.Layout.spacing20)
                .padding(.bottom, LiquidGlassTheme.Layout.spacing40)
            }
        }
    }
}

// MARK: - Data Row
struct DataRow: View {
    let label: String
    let value: String
    @Binding var isEditing: Bool
    
    var body: some View {
        HStack {
            Text(label)
                .font(LiquidGlassTheme.Typography.body)
                .foregroundColor(LiquidGlassTheme.Colors.textSecondary)
            
            Spacer()
            
            if isEditing {
                // TODO: Make editable
                Text(value)
                    .font(LiquidGlassTheme.Typography.headline)
                    .foregroundColor(LiquidGlassTheme.Colors.accent)
            } else {
                Text(value)
                    .font(LiquidGlassTheme.Typography.headline)
                    .foregroundColor(LiquidGlassTheme.Colors.textPrimary)
            }
        }
    }
}

// MARK: - Document Scanner View
struct DocumentScannerView: UIViewControllerRepresentable {
    let completion: (UIImage) -> Void
    
    func makeUIViewController(context: Context) -> VNDocumentCameraViewController {
        let scanner = VNDocumentCameraViewController()
        scanner.delegate = context.coordinator
        return scanner
    }
    
    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(completion: completion)
    }
    
    class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let completion: (UIImage) -> Void
        
        init(completion: @escaping (UIImage) -> Void) {
            self.completion = completion
        }
        
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
            if scan.pageCount > 0 {
                let image = scan.imageOfPage(at: 0)
                completion(image)
            }
            controller.dismiss(animated: true)
        }
        
        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
            controller.dismiss(animated: true)
        }
        
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) {
            controller.dismiss(animated: true)
        }
    }
}

// MARK: - Image Picker
struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration()
        config.filter = .images
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(image: $image)
    }
    
    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        @Binding var image: UIImage?
        
        init(image: Binding<UIImage?>) {
            _image = image
        }
        
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            
            guard let provider = results.first?.itemProvider else { return }
            
            if provider.canLoadObject(ofClass: UIImage.self) {
                provider.loadObject(ofClass: UIImage.self) { image, _ in
                    DispatchQueue.main.async {
                        self.image = image as? UIImage
                    }
                }
            }
        }
    }
}

// MARK: - Glass Progress View Style
struct GlassProgressViewStyle: ProgressViewStyle {
    func makeBody(configuration: Configuration) -> some View {
        ZStack(alignment: .leading) {
            RoundedRectangle(cornerRadius: LiquidGlassTheme.Layout.cornerRadiusSmall)
                .fill(LiquidGlassTheme.Colors.glassLight)
                .frame(height: 8)
            
            RoundedRectangle(cornerRadius: LiquidGlassTheme.Layout.cornerRadiusSmall)
                .fill(
                    LinearGradient(
                        colors: [
                            LiquidGlassTheme.Colors.accent,
                            LiquidGlassTheme.Colors.primary
                        ],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .frame(width: CGFloat(configuration.fractionCompleted ?? 0) * 200, height: 8)
                .animation(AnimationManager.Springs.horizontalSmooth, value: configuration.fractionCompleted)
        }
    }
}